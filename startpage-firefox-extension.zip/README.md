# Startpage Firefox Extension
It's available at Firefox Add-ons: [Firefox Add-ons リンク]

*Note: This is a port of the original Chrome extension created by Yasunori Mahata. I only tested and verified that it works on Firefox without any modifications.*
